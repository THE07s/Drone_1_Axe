/*
 * stm32g4_hc05.h
 *
 *  Created on: Oct 1, 2024
 *      Author: Nirgal
 */

#ifndef BSP_HC_05_STM32G4_HC05_H_
#define BSP_HC_05_STM32G4_HC05_H_

void HC05_set_echo_for_AT_mode(void);

#endif /* BSP_HC_05_STM32G4_HC05_H_ */
