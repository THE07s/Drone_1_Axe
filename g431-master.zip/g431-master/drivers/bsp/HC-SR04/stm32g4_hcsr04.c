/**
 *******************************************************************************
 * @file	stm32g4_hcsr04.c
 * @author	Nirgal			&& Luc H�rault
 * @date	22 mai 2019		&& Juin 2024 --> portage sur g431
 * @brief	Module pour utiliser le HC-SR04
 *******************************************************************************
 */

#include "config.h"
#if USE_HCSR04
#include "stm32g4_hcsr04.h"
#include "stm32g4_utils.h"
#include "stm32g4xx_hal.h"
#include "stm32g4_timer.h"
#include "stm32g4_gpio.h"
#include "stm32g4_extit.h"

#ifndef HCSR04_NB_SENSORS
	#define HCSR04_NB_SENSORS	5
#endif
#ifndef HCSR04_TIMER
	#define HCSR04_TIMER		TIMER1_ID
#endif

//En cas d'absence de mesure, certains HCSR04 pr�sentent un �cho de l'ordre de 130ms.
//Si La p�riode de mesure est inf�rieure, elle ne sera respect�e que si le capteur � pr�sent� un �cho moins long.

static hcsr04_t sensors[HCSR04_NB_SENSORS];

static void HCSR04_callback(uint16_t pin);
static HAL_StatusTypeDef HCSR04_compute_distance(uint8_t id);
static void HCSR04_trig(uint8_t id);
static void HCSR04_RunTimerUs(void);
static uint32_t HCSR04_ReadTimerUs(void);



/**
 * @brief 	Fonction de d�monstration permettant d'apr�hender l'utilisation de ce module logiciel
 * @pre		Cette fonction doit �tre appel�e en t�che de fond
 * @pre		Il faut avoir pr�alablement initialis� un port s�rie (cette fonction utilise printf)
 * @pre 	ATTENTION, le signal ECHO arrive en 5V. Il ne faut pas utiliser pour le recevoir une broche non tol�rante 5V. (voir le classeur Ports_STM32F1.xls)
 * @post 	Cette fonction effectue des mesures r�guli�res avec un capteur HCSR04 plac� sur les ports PC7 (Trig) et PB6 (Echo)
 * @note 	Cette fonction n'utilise que des fonctions publiques. Elle peut donc �tre dupliqu�e � l'ext�rieur de ce module logiciel.
 */
void HCSR04_demo_state_machine(void)
{
	typedef enum
	{
		INIT,
		FAIL,
		LAUNCH_MEASURE,
		RUN,
		WAIT_DURING_MEASURE,
		WAIT_BEFORE_NEXT_MEASURE
	}state_e;

	static state_e state = INIT;
	static uint32_t tlocal;
	static uint8_t id_sensor;
	uint16_t distance;

	//ne pas oublier d'appeler en t�che de fond cette fonction.
	BSP_HCSR04_process_main();


	switch(state)
	{
		case INIT:
			if(BSP_HCSR04_add(&id_sensor, GPIOA, GPIO_PIN_0, GPIOA, GPIO_PIN_1) != HAL_OK)
			{
				printf("HCSR04 non ajout� - erreur g�nante\n");
				state = FAIL;
			}
			else
			{
				printf("HCSR04 ajout�\n");
				state = LAUNCH_MEASURE;
			}
			break;
		case LAUNCH_MEASURE:
			BSP_HCSR04_run_measure(id_sensor);
			tlocal = HAL_GetTick();
			state = WAIT_DURING_MEASURE;
			break;
		case WAIT_DURING_MEASURE:
			switch(BSP_HCSR04_get_value(id_sensor, &distance))
			{
				case HAL_BUSY:
					//rien � faire... on attend...
					break;
				case HAL_OK:
					printf("sensor %d - distance : %d\n", id_sensor, distance);
					state = WAIT_BEFORE_NEXT_MEASURE;
					break;
				case HAL_ERROR:
					printf("sensor %d - erreur ou mesure non lanc�e\n", id_sensor);
					state = WAIT_BEFORE_NEXT_MEASURE;
					break;

				case HAL_TIMEOUT:
					printf("sensor %d - timeout\n", id_sensor);
					state = WAIT_BEFORE_NEXT_MEASURE;
					break;
			}
			break;
		case WAIT_BEFORE_NEXT_MEASURE:
			if(HAL_GetTick() > tlocal + PERIOD_MEASURE)
				state = LAUNCH_MEASURE;
			break;
		default:
			break;
	}
}

/**
 * @pre	Il ne peut pas y avoir plusieurs capteurs sur un m�me num�ro de broche (par exemple PA0 et PB0 !)
 */
HAL_StatusTypeDef BSP_HCSR04_add(uint8_t * id, GPIO_TypeDef * TRIG_GPIO, uint16_t TRIG_PIN, GPIO_TypeDef * ECHO_GPIO, uint16_t ECHO_PIN)
{
	HAL_StatusTypeDef ret;
	ret = HAL_ERROR;
	for(uint8_t i = 0; i<HCSR04_NB_SENSORS; i++)
	{
		if(sensors[i].state == HCSR04_STATE_INEXISTANT)
		{
			//on a trouv� une case libre.
			*id = i;
			sensors[i].state = HCSR04_STATE_INITIALIZED;
			sensors[i].trig_gpio = TRIG_GPIO;
			sensors[i].trig_pin = TRIG_PIN;
			sensors[i].echo_gpio = ECHO_GPIO;
			sensors[i].echo_pin = ECHO_PIN;
			BSP_GPIO_pin_config(ECHO_GPIO, ECHO_PIN, GPIO_MODE_IT_RISING_FALLING, GPIO_PULLDOWN, GPIO_SPEED_FREQ_HIGH, GPIO_NO_AF);
			BSP_GPIO_pin_config(TRIG_GPIO, TRIG_PIN, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, GPIO_SPEED_FREQ_HIGH, GPIO_NO_AF);
			BSP_EXTIT_set_callback(&HCSR04_callback, BSP_EXTIT_gpiopin_to_pin_number(ECHO_PIN), true);
			ret = HAL_OK;
			break;
		}
	}

	return ret;
}

static bool timer_is_running = false;

void BSP_HCSR04_run_measure(uint8_t id)
{
	if(sensors[id].state != HCSR04_STATE_INEXISTANT)
	{
		if(!timer_is_running)
			HCSR04_RunTimerUs();
		HCSR04_trig(id);
	}
}


/**
 * @brief Fonction de callback devant �tre appel�e uniquement par les routines d'interruptions.
 */
static void HCSR04_callback(uint16_t pin)
{
	uint8_t i;
	for(i=0; i<HCSR04_NB_SENSORS; i++)
	{
		if(sensors[i].echo_pin == 1<<pin)	//trouv� !
		{
			if(sensors[i].state == HCSR04_STATE_WAIT_ECHO_RISING)
			{
				if(HAL_GPIO_ReadPin(sensors[i].echo_gpio, sensors[i].echo_pin) == 1)
				{
					sensors[i].trising = HCSR04_ReadTimerUs();
					sensors[i].state = HCSR04_STATE_WAIT_ECHO_FALLING;
				}
			}
			else if(sensors[i].state == HCSR04_STATE_WAIT_ECHO_FALLING)
			{
				if(HAL_GPIO_ReadPin(sensors[i].echo_gpio, sensors[i].echo_pin) == 0)
				{
					sensors[i].tfalling = HCSR04_ReadTimerUs();
					sensors[i].state = HCSR04_STATE_ECHO_RECEIVED;
				}
			}
			break;
		}
	}
}



static void HCSR04_trig(uint8_t id)
{
	if(sensors[id].state != HCSR04_STATE_INEXISTANT)
	{
		uint32_t tlocal;
		sensors[id].state = HCSR04_STATE_TRIG;
		HAL_GPIO_WritePin(sensors[id].trig_gpio, sensors[id].trig_pin, 1);	//trig on
		tlocal = HCSR04_ReadTimerUs();
		while(HCSR04_ReadTimerUs() - tlocal < 10);	//d�lai d'au moins 10us
		HAL_GPIO_WritePin(sensors[id].trig_gpio, sensors[id].trig_pin, 0);	//trig off
		sensors[id].state = HCSR04_STATE_WAIT_ECHO_RISING;
		sensors[id].ttrig = HAL_GetTick();
	}
}

#define HCSR04_PERIOD_TIMER		(40000)				//on compte jusqu'� 40000 * 2.5us = 100ms (soit 34m)
#define HCSR04_PRESCALER_TIMER	(64*10/4)			//on compte des [2.5us] Cette r�solution correspond � 0.85mm

static uint32_t HCSR04_ReadTimerUs(void)
{
	return BSP_TIMER_read(HCSR04_TIMER);
}

static void HCSR04_RunTimerUs(void)
{
	BSP_TIMER_run_us(HCSR04_TIMER, 10000, false);
	BSP_TIMER_set_prescaler(HCSR04_TIMER, HCSR04_PRESCALER_TIMER);
	BSP_TIMER_set_period(HCSR04_TIMER, HCSR04_PERIOD_TIMER);
	timer_is_running = true;
}

void BSP_HCSR04_process_main(void)
{
	uint8_t i;
	for(i=0; i<HCSR04_NB_SENSORS; i++)
	{
		switch(sensors[i].state)
		{
			case HCSR04_STATE_INEXISTANT:
				break;
			case HCSR04_STATE_INITIALIZED:
				//rien � faire, on attend une demande de mesure via HCSR04_run_measure()
				break;
			case HCSR04_STATE_TRIG:
				//neven happen
				break;
			case HCSR04_STATE_WAIT_ECHO_RISING:	//no break;
			case HCSR04_STATE_WAIT_ECHO_FALLING:
				//on attend l'IT...
				if(HAL_GetTick() - sensors[i].ttrig > HSCR04_TIMEOUT)
				{
					sensors[i].state = HCSR04_STATE_TIMEOUT;
				}
				break;
			case HCSR04_STATE_ECHO_RECEIVED:
				//on a correctement re�u un echo
				//calcul de la distance...
				if(HCSR04_compute_distance(i) == HAL_OK)
					sensors[i].state = HCSR04_STATE_IDLE;
				else
					sensors[i].state = HCSR04_STATE_ERROR;
				break;
			case HCSR04_STATE_ERROR:
				//rien � faire, on attend une demande de mesure via HCSR04_run_measure()
				break;
			case HCSR04_STATE_TIMEOUT:
				//rien � faire, on attend une demande de mesure via HCSR04_run_measure()
				break;
			case HCSR04_STATE_IDLE:
				//rien � faire, on attend une demande de mesure via HCSR04_run_measure()
				break;
			default:
				break;
		}
	}
}

static HAL_StatusTypeDef HCSR04_compute_distance(uint8_t id)
{
	uint32_t distance;

	sensors[id].distance = (uint16_t)0;	//hypoth�se tant qu'on a pas une valeur correcte.

	if(sensors[id].state != HCSR04_STATE_ECHO_RECEIVED)
		return HAL_ERROR;

	if(sensors[id].tfalling < sensors[id].trising)
		sensors[id].tfalling += HCSR04_PERIOD_TIMER;

	if(sensors[id].tfalling < sensors[id].trising)
		return HAL_ERROR;

	distance = sensors[id].tfalling - sensors[id].trising;
	distance *=  HCSR04_PRESCALER_TIMER;	//distance est exprim� ici en pulses de timer purs

	uint32_t freq;
	if(HCSR04_TIMER == TIMER1_ID)
	{
		//Fr�quence du TIMER1 est PCLK2 lorsque APB2 Prescaler vaut 1, sinon : PCLK2*2
		freq = HAL_RCC_GetPCLK2Freq();
		if((RCC->CFGR & RCC_CFGR_PPRE2) >> 11 != RCC_HCLK_DIV1)
			freq *= 2;
	}
	else
	{
		//Fr�quence des TIMERS 2,3,4 est PCLK1 lorsque APB1 Prescaler vaut 1, sinon : PCLK1*2
		freq = HAL_RCC_GetPCLK1Freq();
		if((RCC->CFGR & RCC_CFGR_PPRE1) >> 8 != RCC_HCLK_DIV1)
			freq *= 2;
	}
	freq /= 1000000;	//fr�quence exprim�e en MHz
	if(!freq)
		return HAL_ERROR;

	distance /= freq;				//[us]
	distance *= US_SPEED_IN_AIR;	//[um]
	distance /= 1000;				//distance aller-retour [mm]
	distance /= 2;					//distance aller simple [mm]

	if(distance > 5000)//au del� 5m, on consid�re que la distance n'a pas �t� acquise (ou bien est infinie)
		distance = 0;

	sensors[id].distance = (uint16_t)distance;

	return HAL_OK;
}

/**
 * @brief	Cette fonction permet de r�cup�rer la distance mesur�e par le capteur dont l'id est fournie
 * @param	id : identifiant du capteur
 * @param	distance : pointeur vers une case m�moire qui sera renseign�e par cette fonction
 * @return	HAL_OK si la mesure est disponible et fournie. HAL_ERROR sinon.
 * @pre		le capteur doit avoir �t� initialis� pr�alablement
 * @pre		distance doit �tre un pointeur non NULL
 */
HAL_StatusTypeDef BSP_HCSR04_get_value(uint8_t id, uint16_t * distance)
{
	HAL_StatusTypeDef ret = HAL_BUSY;
	switch(sensors[id].state)
	{
		case HCSR04_STATE_IDLE:	//on a re�u une distance
			*distance = sensors[id].distance;
			ret = HAL_OK;
			break;
		case HCSR04_STATE_TIMEOUT:
			ret = HAL_TIMEOUT;
			break;
		case HCSR04_STATE_INEXISTANT:	//no break;		//il est anormal de demander la valeur d'un capteur non initialis�
		case HCSR04_STATE_INITIALIZED:	//no break;		//il est anormal de demander la valeur d'un capteur non lanc� en mesure.
		case HCSR04_STATE_ERROR:						//erreur interne lors du calcul de distance
			ret = HAL_ERROR;
			break;
		default:
			ret = HAL_BUSY;	// tout les autres cas sont 'busy'
			break;
	}
	return ret;
}

#endif
